package kr.or.ddit.service;

import java.sql.SQLException;

public interface MemberService {
	
	public int getMberSequence() throws SQLException;
}
