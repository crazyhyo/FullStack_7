package board.vo;

import board.view.BoardViewImpl;
import board.view.IBoardView;

abstract class BoardChoiceVO implements IBoardChoiceVO{
	protected String choiceName;
	protected String connectedView;
	
	public BoardChoiceVO(String choiceName, String connectedView) {
		this.choiceName = choiceName;
		this.connectedView = connectedView;
	}
	
	public String getChoiceName() {		return choiceName;	}
	public String getConnectedView() {		return connectedView;	}

	abstract public boolean isVaild(BoardVO tempBoard);

	abstract public void afterInput(BoardVO tempBoard);
}

class LOOK extends BoardChoiceVO{
	LOOK(){		super("조회", "BOARD_DETAIL");	}
	IBoardView boardView = BoardViewImpl.getInstance();
	
	@Override
	public BoardVO constructBoardVO(BoardVO tempBoard) {
		tempBoard.setBoardNo(boardView.inputBoardNo());
		return tempBoard;
	}

	@Override
	public boolean isVaild(BoardVO tempBoard) {
		
		return false;
	}

	@Override
	public void afterInput(BoardVO tempBoard) {
		// TODO Auto-generated method stub
		
	}
}

class LIST extends BoardChoiceVO{
	LIST(){		super("목록", "BOARD_LIST");	}
	
	@Override
	public BoardVO constructBoardVO(BoardVO tempBoard) {
		return tempBoard;
	}

	@Override
	public boolean isVaild(BoardVO tempBoard) {
		return true;
	}

	@Override
	public void afterInput(BoardVO tempBoard) {
		// TODO Auto-generated method stub
		
	}
}
class INSERT extends BoardChoiceVO{
	INSERT(){		super("등록", "BOARD_DETAIL");	}
	IBoardView boardView = BoardViewImpl.getInstance();
	
	@Override
	public BoardVO constructBoardVO(BoardVO tempBoard) {
		boardView.inputInsert(tempBoard);
		return tempBoard;
	}

	@Override
	public boolean isVaild(BoardVO tempBoard) {
		return true;
	}

	@Override
	public void afterInput(BoardVO tempBoard) {
		// TODO Auto-generated method stub
		
	}
}
class SEARCH extends BoardChoiceVO{
	SEARCH(){		super("검색", "SEARCHED_LIST");	}
	IBoardView boardView = BoardViewImpl.getInstance();
	
	@Override
	public BoardVO constructBoardVO(BoardVO tempBoard) {
		boardView.inputSearch(tempBoard);
		return tempBoard;
	}

	@Override
	public boolean isVaild(BoardVO tempBoard) {
		return true;
	}

	@Override
	public void afterInput(BoardVO tempBoard) {
		// TODO Auto-generated method stub
		
	}
}
class EXIT extends BoardChoiceVO{
	EXIT(){		super("종료", "EXIT");	}
	@Override
	public BoardVO constructBoardVO(BoardVO tempBoard) {
		return tempBoard;
	}
	@Override
	public boolean isVaild(BoardVO tempBoard) {
		return true;
	}
	@Override
	public void afterInput(BoardVO tempBoard) {
		// TODO Auto-generated method stub
		
	}
}
class UPDATE extends BoardChoiceVO{
	UPDATE(){		super("수정", "BOARD_DETAIL");	}
	IBoardView boardView = BoardViewImpl.getInstance();
	
	@Override
	public BoardVO constructBoardVO(BoardVO tempBoard) {
		boardView.inputUpdate(tempBoard);
		return tempBoard;
	}

	@Override
	public boolean isVaild(BoardVO tempBoard) {
		return true;
	}

	@Override
	public void afterInput(BoardVO tempBoard) {
		// TODO Auto-generated method stub
		
	}
}
class DELETE extends BoardChoiceVO{
	DELETE(){		super("삭제", "BOARD_LIST");	}
	
	@Override
	public BoardVO constructBoardVO(BoardVO tempBoard) {
		return tempBoard;
	}

	@Override
	public boolean isVaild(BoardVO tempBoard) {
		// TODO Auto-generated method stub
		return false;
	}

	@Override
	public void afterInput(BoardVO tempBoard) {
		// TODO Auto-generated method stub
		
	}
}
