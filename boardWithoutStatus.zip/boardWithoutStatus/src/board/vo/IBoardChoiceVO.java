package board.vo;

public interface IBoardChoiceVO {
	public boolean afterInput(BoardVO tempBoard);
}
