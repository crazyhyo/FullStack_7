package board.vo;

public interface IBoardChoiceVO {
	public BoardVO constructBoardVO(BoardVO tempBoard);
}
