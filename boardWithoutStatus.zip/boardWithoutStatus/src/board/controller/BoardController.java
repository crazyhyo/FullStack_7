package board.controller;

import java.util.ArrayList;
import java.util.List;

import board.service.BoardServiceImpl;
import board.service.IBoardService;
import board.view.BoardViewImpl;
import board.view.IBoardView;
import board.vo.BoardScene;
import board.vo.BoardVO;

public class BoardController {
	
	private IBoardService boardService;
	
	private BoardScene scene;
	
	private IBoardView boardView;
	
	BoardController(){
		boardService = BoardServiceImpl.getInstance();
		boardView = BoardViewImpl.getInstance();
		scene = BoardScene.EXIT;
	}
	
	public static void main(String[] args) {
		new BoardController().start();
	}

	private void start() {
		while(true) {
			scene = scene.act();
		}
	}

	private void init(int input, int boardNo, boolean flag, BoardVO tempBoard) {
		input = 0;
		boardNo = 0;
		flag = false;
		tempBoard = new BoardVO();
	}
	
	
}
