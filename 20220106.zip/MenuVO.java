package com.spring.compass.vo;

public class MenuVO {
	
	String menuInnb;
	String menuUrl;
	String menuIcon;
	String upmenuInnb;
	Integer menuIsnav;
	Integer menuLevel;
	String menuNm;
	
	public String getMenuInnb() {
		return menuInnb;
	}
	public void setMenuInnb(String menuInnb) {
		this.menuInnb = menuInnb;
	}
	public String getMenuUrl() {
		return menuUrl;
	}
	public void setMenuUrl(String menuUrl) {
		this.menuUrl = menuUrl;
	}
	public String getMenuIcon() {
		return menuIcon;
	}
	public void setMenuIcon(String menuIcon) {
		this.menuIcon = menuIcon;
	}
	public String getUpmenuInnb() {
		return upmenuInnb;
	}
	public void setUpmenuInnb(String upmenuInnb) {
		this.upmenuInnb = upmenuInnb;
	}
	public Integer getMenuIsnav() {
		return menuIsnav;
	}
	public void setMenuIsnav(Integer menuIsnav) {
		this.menuIsnav = menuIsnav;
	}
	public Integer getMenuLevel() {
		return menuLevel;
	}
	public void setMenuLevel(Integer menuLevel) {
		this.menuLevel = menuLevel;
	}
	public String getMenuNm() {
		return menuNm;
	}
	public void setMenuNm(String menuNm) {
		this.menuNm = menuNm;
	}
	
}
